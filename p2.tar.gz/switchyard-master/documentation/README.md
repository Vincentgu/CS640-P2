# Switchyard documentation

This directory contains Sphinx source (http://sphinx-doc.org/) for Switchyard documentation.

## License

This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
http://creativecommons.org/licenses/by-nc-sa/4.0/
